#!/usr/bin/env python
# coding: utf-8

# In[2]:


"""
Run BWS to compute gold standard scores and output the data in the format used for our semeval task.
"""

from datetime import datetime
import json
import os
import random
import numpy as np
import pandas as pd
from nltk import word_tokenize, OrderedDict

output_dir = '.'  # './data/semeval_humour'
new_data_location = '.'
instances_file = './humour_test_instances.tsv'

# # Output Format
#
# ## humour_test_instances.json
#
# The one-liner documents.
#
# Format: dictionaries with IDs as keys (strings)
# and a list of tokens (strings) as values.
#
# IDs: indexes of the instances in the list of instances. The values should start counting from the total number of documents in the train+dev+old_test sets. The dataset should be shuffled.
#
# Text: needs to be tokenized and lower case. Use word_tokenize from nltk.tokenize.

textdf = pd.read_csv(instances_file, usecols=[0,2], sep='\t')

new_test_insts = {}
for _, rows in textdf.iterrows():
    tokens = word_tokenize(rows["Joke text"])
    tokens = [t.lower() for t in tokens]
    new_test_insts[rows["ID"]] = tokens

with open(os.path.join(output_dir, 'humour_test_instances.json'), 'w') as fh:
    json.dump(new_test_insts, fh)
