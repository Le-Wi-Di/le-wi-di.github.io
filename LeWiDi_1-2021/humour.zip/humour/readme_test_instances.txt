For copyright reasons, the text data for the test instances must be downloaded by running:

`
perl fetch_potd.pl humour_test_instances.tsv
`

This downloads the test instances into the TSV format. To get the data into the JSON format as used for the train and dev data, run:

`
python get_humour_test_instances.py
`

This will output the file to humour_test_instances.json.
